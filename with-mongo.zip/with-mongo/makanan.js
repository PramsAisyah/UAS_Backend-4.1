const express = require("express");
const routerMakanan = express.Router()

let makanan = [{menu:'Betawi', minuman:'Jeruk', porsi:'sedang', harga:'20',create:new Date()},
                 {menu:'Ayam Geprek', minuman:'Teh', porsi:'sedang', harga:'15',create:new Date()},
                 {menu:'Nasi Goreng', minuman:'Temulawak', porsi:'besar', harga:'15',create:new Date()},
                ]

const cari = (arrData,menu) =>{
    ketemu = -1
    indeks = 0
    while(ketemu == -1 && indeks < arrData.length){
        if(arrData[indeks].menu == menu){
            ketemu = indeks
            return indeks
        }
        indeks++
    }
    return -1
}

routerSepatu.route('/makanan')
    .get( (req,res)=>{
        res.json(makanan)
    })

    .post((req,res)=>{
        //Ambil data request dari front end
        const newItem = {
            menu: req.body.menu,
            minuman : req.body.minuman,
            porsi : req.body.porsi,
            harga : req.body.harga
        }
        sepatu.push(newItem)
        res.status(201).json(newItem)
    })

routerSepatu.route('/makanan/:menu')
    .put((req,res)=>{
        menu = req.params.menu
        indeks = cari(makanan,menu)
        if(indeks != -1){
            makanan[indeks].menu = menu
            makanan[indeks].minuman = req.body.minuman
            makanan[indeks].porsi = req.body.porsi
            makanan[indeks].harga = req.body.harga

            res.json(makanan[indeks])
        }
        else{
            res.send('Data Menu makanan tidak ditemukan')
        }
        
    })

    .delete((req,res)=>{
        menu = req.params.menu
        indeks = cari(makanan,menu)
        if(indeks != -1){
            makanan.splice(indeks,1)
            res.send('Makanan dengan Menu ' + menu + ' telah dihapus')
        }
        else
        {
            res.send('Data Menu makanan tidak ditemukan')
        }
        
    })

    .get((req,res)=>{
        menu = req.params.menu
        indeks = cari(makanan,menu)
        if(indeks != -1){
            const dataMakanan = {menu:makanan[indeks].menu,
                                   minuman:makanan[indeks].minuman,
                                   porsi:makanan[indeks].porsi,
                                   harga:sepatu[indeks].harga
                                  }
            res.json(dataMakanan)
        }
        else{
            res.send('Makanan dengan menu : ' + menu + ' tidak ditemukan')
        }
        
    })

routerMakanan.get('/makanan/:ukuran/:terlaris', (req,res)=>{
    const ukuran = req.params.ukuran
    const terlaris = req.params.terlaris
    res.send('Makanan : ' + ukuran + ' terlaris : ' + terlaris)
})

module.exports = routerMakanan