const express = require("express");
const routerMakanan = express.Router()
const controllerMakanan = require('../controllers/makanan')

routerMakanan.route('/sepatu')
    .get(controllerMakanan.getMakanan)
    .post(controllerMakanan.insert)

routerMakanan.route('/makanan/:menu')
    .put(controllerMakanan.update)
    .delete(controllerMakanan.delete)
    .get(controllerMakanan.getMakananByMenu)

routerMakanan.route('/makanan/produk/:menu')
    .get(controllerMakanan.getProdukByMenu)
    .put(controllerMakanan.insertProduk)

module.exports = routerMakanan