const Makanan = require('../models/mknEmbedded')


module.exports = {
    insert : async (req,res)=>{
        //Ambil data request dari front end
        const data = new Makanan({
            menu : req.body.menu,
            minuman : req.body.minuman,
            porsi : req.body.porsi,
            harga : req.body.harga,
        })
        try {
            const dataToSave = await data.save()
            res.status(200).json(dataToSave)
        } catch (error) {
            res.status(400).json({message:error.message})
        }
    },

    insertProduk: async (req,res)=>{
        const menu = req.params.menu

        try{
            await Makanan.updateOne(
                {"menu":menu},
                {
                    $push:{
                        "produk":{
                            "kode": req.body.kode,
                            "jenismakanan": req.body.jenismakanan,
                            "kualitas":req.body.kualitas,
                            'porsi':req.body.porsi,
                            "harga": req.body.harga,
                        }
                    }
                })
            res.send('Produk telah di simpan')
            } catch (error){
                res.status(409).json({message: error.message})
            }
    },
    
    getMakanan : async (req,res)=>{
        try {
            const result = await Makanan.find()
            res.status(200).json(result)
        } catch (error) {
            res.status(404).json({message : error.message})
        }
    },
    getMakananByMenu : async (req,res)=>{
         const merk = req.params.menu
         try {
             const result = await Sepatu.find().where('menu').equals(menu)
             res.json(result)
         } catch (error) {
             res.status(500).json({message: error.message})
         }
    },

    getMakananByMenu : async (req,res) => {
        const merk = req.params.menu;
        try{
            const result = await Sepatu.findOne({"menu": menu}, {"_id":0,"produk": 1})
            /* let res2 =[];
            for (let i = 0; i < result.lenght i++){
                res2.push(result[i])
            }*/
            res.json(result)
        } catch (error){
            res.status(500).json({ message : error.message})
        }
    },
    update : async (req,res)=>{
        const filter = {menu : req.params.menu}
        const updatedData = {
            minuman : req.body.minuman,
            porsi : req.body.porsi,
            harga : req.body.harga
        }
        try {
            let result = await Makanan.updateOne(filter,updatedData)
            res.send('Data telah terupdate')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    },

    delete : async (req,res)=>{
        const filter = {menu : req.params.menu}
        try {
            await Makanan.deleteOne(filter);
            res.send('Data telah terhapus')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    }
}