const mongoose = require('mongoose')

const mknEmbeddedSchema = new mongoose.Schema({
    menu:{
        required: true,
        type: String
    },
    minuman:{
        required: true,
        type: String
    },
    porsi:{
        required: true,
        type: String
    },
    harga:{
        required: true,
        type: String
    },
    produk: [{
        kode : String,
        jenismakanan : String,
        kualitas : String,
        porsi : String,
        harga : String
    }]
})

module.exports = mongoose.model('Makanan', mknEmbeddedSchema,'makanan')