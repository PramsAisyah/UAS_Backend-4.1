const mongoose = require('mongoose')

const mknSchema = new mongoose.Schema({
    merk : {
        require : true,
        type : String
    },
    minuman : String,
    porsi : String,
    harga : String,
})

module.exports = mongoose.model('Makanan', mknSchema,'makanan')